from flask import Flask,render_template,request,redirect,session
import os

app = Flask(__name__)

UPLOAD_TO  = "C:/Users/gmohan/python/ACI_GW/Dev3"
ALLOWED_EXTS =["csv","txt","jpg","jpeg"]

def check_file(file):
      return "." in file and file.rsplit(".",1)[1].lower() in ALLOWED_EXTS

@app.route("/upload", methods=["GET", "POST"])
def upload():
    error = None
    filename = None
    if request.method == "POST":

        if "file" not in request.files:
            error = "File not selected"
            return render_template('upload.html', error = error)

        # Get the filename from upload.html
        file= request.files['file']
        filename = file.filename
        
        if filename=='':
                error = "Filename is empty"
                return render_template('upload.html', error = error)

        if check_file(filename)==False:
            error = "This file isn't Allowed"
            return render_template('upload.html', error = error)
        file.save(os.path.join(UPLOAD_TO,filename))
    return render_template('upload.html', error = error,filename=filename)


